const renderer = cc.renderer
const Materials = require('Materials')
var SpriteMaterial = renderer.renderEngine.SpriteMaterial
const math = renderer.renderEngine.math;
var meshData = require('mj_mesh')
cc.Class({
    extends: cc.RenderComponent,
    properties: {
        testMeshName:"",
        texture: {
            default: null,
            type: cc.SpriteFrame,
        },
        meshScale:1,
        rot_x:0,
        rot_y:0,
        rot_z:0,
    },
    // use this for initialization
    onLoad: function () {
        this.node._scale.x = this.meshScale;
        this.node._scale.y = this.meshScale;
        this.node._scale.z = this.meshScale;
        math.quat.fromEuler(this.node._quat,this.rot_x,this.rot_y,this.rot_z)
        this._activateMaterial();
        if(this.testMeshName!=""){
            this._meshData = meshData[this.testMeshName];
        }
    },

    _activateMaterial: function () {
        // Get material
        let texture = this.texture.getTexture();
        let url = texture.url;
        let key = url;
        var material = renderer.materialUtil.get(key);
        
        if (!material) {
            material = new Materials.SimpleMeshMaterial();
            renderer.materialUtil.register(key, material);
        }
        material.setTexture(texture.getImpl());
        this._material = material
    },
    
})._assembler = require('mesh-assembler');
